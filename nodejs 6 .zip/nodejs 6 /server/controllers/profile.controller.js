import { ProfileModel } from '../models/profile.model.js';

export const getAllProfiles = async (req, res) => {
  const profiles = await ProfileModel.findAll();
  return res.json(profiles);
};

export const getProfileById = async (req, res) => {
  const profile = await ProfileModel.findByPk(req.params.id);
  return res.json(profile);
};

export const createProfile = async (req, res) => {
  const { name, age, email, bio, location } = req.body;
  const createdProfile = await ProfileModel.create({ name, age, email, bio, location });
  return res.json(createdProfile);
};

export const updateProfile = async (req, res) => {
  const id = req.params.id;
  // Lógica para atualizar o perfil com o ID fornecido
  return res.json({ api: 'update' });
};

export const deleteProfile = async (req, res) => {
  const id = req.params.id;
  // Lógica para excluir o perfil com o ID fornecido
  return res.json({ api: 'deleteProfile' });
};
