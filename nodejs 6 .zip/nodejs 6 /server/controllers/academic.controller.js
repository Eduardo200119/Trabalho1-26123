import { AcademicModel } from '../models/academic.model.js';

export const getAllAcademics = async (req, res) => {
  const academics = await AcademicModel.findAll();
  return res.json(academics);
};

export const getAcademicById = async (req, res) => {
  const academic = await AcademicModel.findByPk(req.params.id);
  return res.json(academic);
};

export const createAcademic = async (req, res) => {
  const { name, field, degree } = req.body;
  const createdAcademic = await AcademicModel.create({ name, field, degree });
  return res.json(createdAcademic);
};

export const updateAcademic = async (req, res) => {
  const idAcademic = req.params.idUpdate;
  const body = req.body;
  const updateAcademic = await AcademicModel.update(
    {
      name: body.eduacationName,
      field: body.field,
      degree: body.degree,
  
    },
    {
      where: { id: idAcademic },
    }
  );
  // Lógica para atualizar a experiência com o ID fornecido
  return res.json({ api: "upadateAcademic" });
};

export const deleteAcademic = async (req, res) => {
  const id = req.params.idDelete;
  const deleteAcademic = await AcademicModel.destroy({
    where: { id: id },
  });
  //const deleteExperience = await ExperienceModel.deleteExperience(id);
  // Lógica para excluir a experiência com o ID fornecido
  return res.json({ api: "deleteAcademic" });
};