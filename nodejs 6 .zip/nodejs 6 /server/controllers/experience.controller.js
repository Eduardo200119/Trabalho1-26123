import { Sequelize } from "sequelize";
import { ExperienceModel } from "../models/experience.model.js";

/* uso do Sequelize */

export const getAllExperiences = async (req, res) => {
  const experiences = await ExperienceModel.findAll();
  return res.json(experiences);
};

export const getExperienceById = async (req, res) => {
  const experience = await ExperienceModel.findByPk(req.params.id);
  return res.json(experience);
};

/* uso do metodo create do Sequelize para adicionar uma nova entarda da tabela experience */
export const createExperience = async (req, res) => {
  const { company, position, years, description } = req.body;
  const createdExperience = await ExperienceModel.create({
    company,
    position,
    years,
    description,
  });
  return res.json(createdExperience);
};

/* uso do metodo update do Sequelize para atualizar uma entarda exixstente da tabela experience */
/* apenas editar o registo que tem como id o idExperience enviado nos parametros do url req */
export const updateExperience = async (req, res) => {
  const idExperience = req.params.idUpdate;
  const body = req.body;
  const updateExperience = await ExperienceModel.update(
    {
      company: body.company,
      description: body.description,
      position: body.position,
      years: body.years,
    },
    {
      where: { id: idExperience },
    }
  );
  // Lógica para atualizar a experiência com o ID fornecido
  return res.json({ api: "updateExperience" });
};
/* uso do metodo delete  do Sequelize para atualizar uma entarda exixstente da tabela experience */
/* apenas editar o remover que tem como id o idExperience enviado nos parametros do url req */

export const deleteExperience = async (req, res) => {
  const id = req.params.idDelete;
  const deleteExperience = await ExperienceModel.destroy({
    where: { id: id },
  });
  //const deleteExperience = await ExperienceModel.deleteExperience(id);
  // Lógica para excluir a experiência com o ID fornecido
  return res.json({ api: "deleteExperience" });
};
