import { INTEGER, STRING } from "sequelize";
import { database } from "../config/context/database.js";

const ProfileModel = database.define("profile", {
  id: {
    type: INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  name: {
    type: STRING,
    allowNull: false,
  },
  age: {
    type: INTEGER,
    allowNull: false,
  },
  email: {
    type: STRING,
    allowNull: false,
    unique: true,
  },
  bio: {
    type: STRING,
    allowNull: true,
  },
  location: {
    type: STRING,
    allowNull: true,
  },
});

export { ProfileModel };
