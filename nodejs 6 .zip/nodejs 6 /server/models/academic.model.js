import { INTEGER, STRING } from "sequelize";
import { database } from "../config/context/database.js";

const AcademicModel = database.define("academic", {
  id: {
    type: INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  name: {
    type: STRING,
    allowNull: false,
  },
  field: {
    type: STRING,
    allowNull: false,
  },
  degree: {
    type: STRING,
    allowNull: false,
  },
});
export { AcademicModel };
