import Router from 'express';
import {
getAllAcademics,
getAcademicById,
  createAcademic,
  updateAcademic,
  deleteAcademic,
} from '../controllers/academic.controller.js';
import { authRequired } from '../utils/jwt.js';


//--ROUTES--//
const academicRoutes = Router();

// http://localhost:4242/api/...
academicRoutes.get('/getAll', authRequired, getAllAcademics);
academicRoutes.get('/getById/:idGet', getAcademicById);
academicRoutes.post('/create', authRequired, createAcademic);
academicRoutes.put('/update/:idUpdate', updateAcademic);
academicRoutes.delete('/delete/:idDelete', deleteAcademic);
export {academicRoutes} ;
