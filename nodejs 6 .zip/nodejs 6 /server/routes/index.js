import Router from "express";

import { todoRoutes } from "./todo.routes.js";
import { usersRoutes } from "./user.routes.js";
import { profileRoutes } from "./profile.routes.js";
import { academicRoutes } from "./academic.routes.js";
import {experienceRoutes } from "./experience.routes.js";


const api = Router();
// http://localhost:4242/api/todo ....
api.use("/todo", todoRoutes);

// http://localhost:4242/api/user ....
api.use("/user", usersRoutes);

api.use("/profile", profileRoutes);

api.use("/academic", academicRoutes );

api.use("/experience", experienceRoutes);


export { api };
