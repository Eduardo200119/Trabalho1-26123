import Router from "express";
import {
  getAllProfiles,
  getProfileById,
  createProfile,
  updateProfile,
  deleteProfile,
} from "../controllers/profile.controller.js";
import { authRequired } from "../utils/jwt.js";

//--ROUTES--//
const profileRoutes = Router();

// http://localhost:4242/api/...
profileRoutes.get("/getAll", authRequired, getAllProfiles);
profileRoutes.get("/getById/:idGet", getProfileById);
profileRoutes.post("/create", authRequired, createProfile);
profileRoutes.put("/update/:idUpdate", updateProfile);
profileRoutes.delete("/delete/:idDelete", deleteProfile);

export { profileRoutes };
