import Router from "express";
import {
  getAllExperiences,
  getExperienceById,
  createExperience,
  updateExperience,
  deleteExperience,
} from "../controllers/experience.controller.js";
import { authRequired } from "../utils/jwt.js";

//--ROUTES--//
const experienceRoutes = Router();

// http://localhost:4242/api/todo/getAll
experienceRoutes.get("/getAll", authRequired, getAllExperiences);
experienceRoutes.get("/getById/:idGet", getExperienceById);
experienceRoutes.post("/create", authRequired, createExperience);
experienceRoutes.put("/update/:idUpdate", updateExperience);
experienceRoutes.delete("/delete/:idDelete", authRequired, deleteExperience);

export { experienceRoutes };
